/**
 * @authors Rami Abdul Majeed, Sara Al-Abbasi, Mohamed Alhasan, Kareem Elgendy, Omar Kato
 * @brief The main function that runs the program
 */

#include <fstream>
#include <string>
#include <iostream>
#include <vector>
#include "Student.h"
#include "Device.h"
#include "Database.h"
#include "Test_driver.h"

using namespace std;

int main(int argc, char **argv)
{
  Database db = Database("./database.db");

  cout << "--------------" << endl;

  // atleast 1 argument is passed
  if (argc > 1)
  {
    if (strcmp(argv[1], "Admin") == 0)
    {
      Table table = db.getTable(argv[2]);
      string command;
      if (strcmp(argv[3], "register_student") == 0)
      {
        //./control_center Admin Student register_student <ID> <Name> <ENROLMENT> <BUS_PASS> <PARKING_PASS> <MEAL_PLAN> <MEAL_PLAN_LIMIT_REACHED> <MC_PERMISSION> <NSB_PERMISSION> <EH_PERMISSION>
        command = string("'") + argv[4] + "', '" + argv[5] + "', '" + argv[6] + "', '" + argv[7] + "', '" + argv[8] + "', '" + argv[9] + "', '" + argv[10] + "', '" + argv[11] + "', '" + argv[12] + "', '" + argv[13] + "'";
        table.insert(command);
      }
      else if (strcmp(argv[3], "remove_student") == 0)
        //./control_center Admin Student remove_student <student_id>
        table.remove(argv[4]);
      else if (strcmp(argv[3], "update_student_info") == 0)
        //./control_center Admin Student update_student_info <student_id>, <columnName>, <newValue>
        table.update(argv[4], argv[5], argv[6]);
      else if (strcmp(argv[2], "Room") == 0)
      {
        if (strcmp(argv[3], "add_room") == 0)
        {
          //./control_center Admin Room add_room <ROOM_ID> <AVAILABILITY> <STUDENT_ID>
          command = string("'") + argv[4] + "', '" + argv[5] + "', '" + argv[6] + "'";
          table.insert(command);
        }
        else if (strcmp(argv[3], "remove_room") == 0)
          //./control_center Admin Room remove_room <Room_ID>
          table.remove(argv[4]);
        else if (strcmp(argv[3], "update_room_info") == 0)
          //./control_center Admin Room update_room_info <room_id>, <columnName>, <newValue>
          table.update(argv[4], argv[5], argv[6]);
      }
      else if (strcmp(argv[2], "Location") == 0)
      {
        if (strcmp(argv[3], "add_location") == 0)
        {
          //./control_center Admin Product <action> <location_id> <location_name>
          command = string("'") + argv[4] + "', '" + argv[5] + "'";
          table.insert(command);
        }
        else if (strcmp(argv[3], "remove_location") == 0)
          //./control_center Admin Location <action> <location_id>
          table.remove(argv[4]);
        else if (strcmp(argv[3], "update_location") == 0)
          //./control_center Admin Location <action> <location_id> <column> <newValue>
          table.update(argv[4], argv[5], argv[6], "Location", "ID");
      }
      else if (strcmp(argv[2], "Product") == 0)
      {
        if (strcmp(argv[3], "add_product") == 0)
        {
          //./control_center Admin Product <action> <product_id> <location_name> <product_name> <product_price> <product_stock>
          command = string("'") + argv[4] + "', '" + argv[5] + "', '" + argv[6] + "', '" + argv[7] + "', '" + argv[8] + "'";
          table.insert(command);
        }
        else if (strcmp(argv[3], "remove_product") == 0)
          //./control_center Admin Product <action> <product_id>
          table.remove(argv[4]);
        else if (strcmp(argv[3], "update_product") == 0)
          //./control_center Admin Product <action> <product_id> <column> <newValue>
          table.update(argv[4], argv[5], argv[6], "Product", "ID");
      }
    }
    else if (strcmp(argv[3], "increaseBalance") == 0)
    {
      Device(001, argv[4], db, "Student").perform(Student(argv[1], stod(argv[2])), argv[3], atoi(argv[5]));
    }
    else if (strcmp(argv[3], "purchaseFood") == 0)
    {
      Device(002, argv[4], db, "Student").perform(Student(argv[1], stod(argv[2])), argv[3], atoi(argv[5]));
    }
    else if (strcmp(argv[3], "purchase") == 0)
    {
      Device(002, argv[4], db, "Student").purchase(Student(argv[1], stod(argv[2])), argv[5]);
    }
    else if (strcmp(argv[3], "refund") == 0)
    {
      Device(002, argv[4], db, "Student").refund(Student(argv[1], stod(argv[2])), argv[5]);
    }
    else if (strcmp(argv[3], "viewBalance") == 0)
    {
      Device(003, argv[4], db, "Student").perform(Student(argv[1], stod(argv[2])), argv[3], 0);
    }
    else if (strcmp(argv[3], "validateBusPass") == 0)
    {
      Device(004, argv[4], db, "Student").validateBusPass(Student(argv[1], stod(argv[2])));
    }
    else if (strcmp(argv[3], "bookRoom") == 0)
    {
      Device(005, argv[4], db, "Room").book(Student(argv[1], stod(argv[2])), argv[5]);
    }
    else if (strcmp(argv[3], "AccessParking") == 0)
    {
      Device(006, argv[4], db, "Student").perform(Student(argv[1], stod(argv[2])), argv[3], atoi(argv[5]));
    }
    else if (strcmp(argv[3], "ValidateMP") == 0)
    {
      Device(007, argv[4], db, "Student").ValidateMP(Student(argv[1], stod(argv[2])));
    }
    else if (strcmp(argv[3], "printScan") == 0)
    {
      Device(010, argv[4], db, "Student").printScan((Student(argv[1], stod(argv[2]))), argv[5], argv[6], atoi(argv[7]));
    }
    else if (strcmp(argv[3], "AccessBuilding") == 0)
    {
      Device(011, argv[4], db, "Student").perform(Student(argv[1], stod(argv[2])), argv[3], 0);
    }
    else if (strcmp(argv[1], "Regression") == 0)
      Test_driver regression = Test_driver();
    else
      cout << "invalid options";
  }
  else
  {
    cout << "No arguments passed, try again." << endl;
    return 1;
  }
  return 0;
}