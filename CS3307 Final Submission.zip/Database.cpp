/**
 * @authors Kareem Elgendy, Omar Kato
 * @brief This class represents the database and is responsible for creating the Database object
 */

#include "Database.h"

/**
 * @brief Class constructor
 * @param name The database name
 */
Database::Database(string name)
{
    string student = "ID TEXT PRIMARY KEY NOT NULL,"
                     "NAME TEXT NOT NULL,"
                     "ENROLMENT TEXT NOT NULL,"
                     "BUS_PASS TEXT NOT NULL,"
                     "PARKING_PASS TEXT NOT NULL,"
                     "MEAL_PLAN TEXT NOT NULL,"
                     "MEAL_PLAN_LIMIT_REACHED TEXT NOT NULL,"
                     "MC_PERMISSION TEXT NOT NULL,"
                     "NSB_PERMISSION TEXT NOT NULL,"
                     "EH_PERMISSION TEXT NOT NULL";

    string room = "ID TEXT PRIMARY KEY NOT NULL,"
                  "AVAILABILITY TEXT NOT NULL,"
                  "STUDENT_ID TEXT NOT NULL";

    string location = "ID TEXT PRIMARY KEY NOT NULL,"
                      "NAME TEXT NOT NULL";

    string product = "ID TEXT PRIMARY KEY NOT NULL,"
                     "LOCATION TEXT NOT NULL,"
                     "NAME TEXT NOT NULL,"
                     "PRICE TEXT NOT NULL,"
                     "STOCK TEXT NOT NULL";

    int exit = 0;
    exit = sqlite3_open(name.c_str(), &db);

    if (exit)
        cout << "Failed to create database" << endl;
    else
    {
        createTable("Student", student);
        createTable("Room", room);
        createTable("Location", location);
        createTable("Product", product);
    }
}

/**
 * @brief Class destructor
 */
Database::~Database() {}

/**
 * @brief Creates a table
 * @param tableName the name of the table
 * @param columns the columns in the table
 */
void Database::createTable(string tableName, string columns)
{
    this->tables.push_back(Table(tableName, columns, this->db));
}

/**
 * @brief Drops a table
 * @param tableName the name of the table
 */
void Database::dropTable(string tableName)
{
    char *msg;
    string command = "DROP TABLE " + tableName;
    sqlite3_exec(db, command.c_str(), NULL, 0, &msg);
}

/**
 * @brief returns a table
 * @param tableName the name of the table
 */
Table Database::getTable(string tableName)
{
    for (int i = 0; i < tables.size(); i++)
    {
        if (tables[i].getName() == tableName)
            return tables[i];
    }
    return Table();
}