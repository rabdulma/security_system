/**
 * @authors Rami Abdul Majeed, Sara Al-Abbasi, Mohammed Alhasan, Kareem Elgendy, Omar Kato
 * @brief This is the header file for the student class
 */

#ifndef STUDENT_H
#define STUDENT_H

#include <string>
#include <iostream>

using namespace std;

class Student
{
private:
    string id;      /**< The student's ID */
    double balance; /**< The student's account balance */

public:
    Student(string id, double balance);
    ~Student();
    string getID();
    void setID(string id);
    double getBalance();
    void setBalance(string action, double amount);
};

#endif
