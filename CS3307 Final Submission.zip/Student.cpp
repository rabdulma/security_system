/**
 * @authors Rami Abdul Majeed, Sara Al-Abbasi, Mohammed Alhasan, Kareem Elgendy, Omar Kato
 * @brief This class represents the student and is responsible for creating Student objects
 */

#include "Student.h"

/**
 * @brief Class constructor: Used to create a new student
 * @param id The student's ID
 * @param balance The student's initial balance
 */
Student::Student(string id, double balance)
{
    this->id = id;
    this->balance = balance;
}

/**
 * @brief Class destructor
 */
Student::~Student() {}

/**
 * @brief Getter method
 * @return The student ID of type string
 */
string Student::getID()
{
    return this->id;
}

/**
 * @brief Setter method:
 * Sets the student's ID to the ID passed
 * @param id The student ID
 */
void Student::setID(string id)
{
    Student::id = id;
}

/**
 * @brief Getter method:
 * Returns the balance
 * @return The student's balance of type double
 */
double Student::getBalance()
{
    return this->balance;
}

/**
 * @brief Setter method:
 * Adds/subtracts to/from the student's balance depending on the action
 * @param action The action that will be performed
 * @param amount The amount to add/subtract from the student's balance
 */
void Student::setBalance(string action, double amount)
{
    if (action == "increment")
    {
        if (amount > 0)
            this->balance += amount;
    }
    else if (action == "decrement")
    {
        if (amount <= this->balance)
            this->balance -= amount;
    }
    else if (action == "set")
    {
        if (amount > 0)
            this->balance = amount;
    }
    else
    {
        cout << "Action not supported." << endl;
    }
}