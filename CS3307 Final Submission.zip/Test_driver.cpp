/**
 * @authors Rami Abdul Majeed, Sara Al-Abbasi, Mohamed Alhasan, Kareem Elgendy, Omar Kato
 * @brief The main function that runs the program
 */

#include "Test_driver.h"
using namespace std;

Test_driver::Test_driver()
{
  Database db = Database("./database.db");

  // Table studentTable = db.getTable("Student");
  // Table roomTable = db.getTable("Room");
  // Table productTable = db.getTable("Product");
  // Table locationTable = db.getTable("Location");

  // studentTable.insert("'123', 'Omar Kato', 'YES', 'ACTIVE', 'ACTIVE', 'YES', 'NO', 'YES', 'YES', 'YES'");
  // studentTable.insert("'456', 'Kareem Elgendy', 'NO', 'INACTIVE', 'ACTIVE', 'NO', 'YES', 'NO', 'YES', 'YES'");
  // studentTable.insert("'789', 'Mohammed Al-Hassan', 'YES','ACTIVE', 'PRIVATE', 'NO', 'YES', 'YES', 'NO', 'YES'");
  // studentTable.insert("'987', 'Sarah Al-Abbasi', 'YES', 'INACTIVE', 'INACTIVE', 'YES', 'YES', 'YES', 'YES', 'NO'");
  // studentTable.insert("'654', 'Rami Abdul Majeed', 'NO', 'INACTIVE', 'INACTIVE', 'NO', 'YES', 'NO', 'NO', 'NO'");

  // roomTable.insert("'100_1-2', 'YES', ''");
  // roomTable.insert("'200_1-2', 'YES', ''");
  // roomTable.insert("'300_1-2', 'YES', ''");
  // roomTable.insert("'400_1-2', 'YES', ''");
  // roomTable.insert("'100_3-4', 'YES', ''");
  // roomTable.insert("'200_3-4', 'YES', ''");
  // roomTable.insert("'300_3-4', 'YES', ''");
  // roomTable.insert("'400_3-4', 'YES', ''");
  // roomTable.insert("'100_5-6', 'YES', ''");
  // roomTable.insert("'200_5-6', 'YES', ''");
  // roomTable.insert("'300_5-6', 'YES', ''");
  // roomTable.insert("'400_5-6', 'YES', ''");

  // productTable.insert("'1', 'Campus Bookstore', 'Western Hoodie', '50.00', '1250'");
  // productTable.insert("'2', 'Campus Bookstore', 'Western Tshirt', '45.50', '0'");
  // productTable.insert("'3', 'Campus Bookstore', 'Textbook', '349.99', '100'");
  // productTable.insert("'4', 'Pharmacy', 'Advil', '25.00', '5'");
  // productTable.insert("'5', 'Pharmacy', 'Tylenol', '34.99', '45'");

  // locationTable.insert("'1', 'Student center'");
  // locationTable.insert("'2', 'Nursing building'");
  // locationTable.insert("'3', 'Computer Science building'");
  // locationTable.insert("'4', 'Astronomy building'");
  // locationTable.insert("'5', 'Campus Bookstore'");

  /** -------------------------------------
   * Test cases - story #2 - Kareem Elgendy
   * Acceptance Criteria (TC 1 & 2):
   * 1. Initial balance should equal 750
   * 2. The new balance should equal 1000
   */
  cout << "------------" << endl;
  Student studentOne = Student("123", 750.00);
  Device topupMachine = Device(001, "Student Center", db, "Student");
  topupMachine.perform(studentOne, "increase balance", 250.00);
  cout << "------------" << endl;

  /**
   * Acceptance Criteria (TC 3):
   * 1. Initial balance should equal 750
   * 2. Should print a message saying Student not enrolled.
   * 3. No balance should be updated
   */
  Student notStudent = Student("456", 750.00);
  topupMachine.perform(notStudent, "increase balance", 250.00);
  cout << "------------" << endl;

  // /**
  //  * Sara Al-Abbasi
  //  * https://jira.csd.uwo.ca/browse/COMPSCI3307F2022GROUP6-12
  //  * AC1( TC 1&4):
  //  * 1. valid student ID
  //  * 2. valid enrolment status
  //  * 3. balance greater than 0 or greater than or equal to cost
  //  * Expected result: Pass (Purchase completed successfully)
  //  */
  cout << "AC1 result:" << endl;
  double balance = 100;
  Student student = Student("123", balance);
  Device device = Device(002, "Cafeteria", db, "Student");
  int costOfItem = 20;
  device.perform(student, "purchaseFood", costOfItem);

  // /**
  //  * AC2( TC 2):
  //  * Invalid student ID
  //  * Expected result: Fail (Student not found in database)
  //  */
  cout << "AC2 result:" << endl;
  Student invalidStudent = Student("12345", 100);
  device.perform(invalidStudent, "purchaseFood", costOfItem);

  // /**
  //  * AC3( TC 3):
  //  * 1. Valid student ID
  //  * 2. Invalid enrolment status
  //  * Expected result: Fail (Student not enrolled. Could not complete purchase)
  //  */
  cout << "AC3 result:" << endl;
  Student notEnrolledStudent = Student("456", balance);
  device.perform(notEnrolledStudent, "purchaseFood", costOfItem);

  // /**
  //  * AC4( TC 5):
  //  * 1. Valid student
  //  * 2. Balance greater than 0 but less than cost
  //  * Expected result: Fail (You do not have enough credit.)
  //  */
  cout << "AC4 result:" << endl;
  costOfItem = 500;
  device.perform(student, "purchaseFood", costOfItem);
  cout << "------------" << endl;

  // /**
  //  * Sara Al-Abbasi
  //  * https://jira.csd.uwo.ca/browse/COMPSCI3307F2022GROUP6-14
  //  * AC1( TC 1):
  //  * valid student ID
  //  * Expected result: Pass (Student is able to view their balance successfully)
  //  */
  cout << "AC1 result:" << endl;
  Student studenT = Student("123", 100);
  Device topUpMachine = Device(003, "top-up machine", db, "Student");
  topUpMachine.perform(studenT, "viewBalance", 0);
  // /**
  //  * AC2( TC 2):
  //  * Invalid student ID
  //  * Expected result: Fail (Student is not able to view their balance successfully)
  //  */
  cout << "AC2 result:" << endl;
  Student studenTinvalid = Student("123df", 100);
  topUpMachine.perform(studenTinvalid, "viewBalance", 0);
  cout << "------------" << endl;
  // /**
  //  * Sara Al-Abbasi
  //  * https://jira.csd.uwo.ca/browse/COMPSCI3307F2022GROUP6-11
  //  * AC1( TC 1&3&5):
  //  * 1. valid student ID
  //  * 2. valid enrolment status
  //  * 3. Valid Bus pass
  //  * Expected result: Pass (Student successfully gains access to the buses in London)
  //  */
  cout << "AC1 result:" << endl;
  Device busPass = Device(004, "bus", db, "Student");
  busPass.validateBusPass(student);

  // /**
  //  * AC2( TC 2):
  //  * Invalid student ID
  //  * Expected result: Fail (Student not found in database)
  //  */
  cout << "AC2 result:" << endl;
  busPass.validateBusPass(Student("1000", 0.0));

  // /**
  //  * AC3( TC 4):
  //  * 1. Valid student ID
  //  * 2. Invalid enrolment status
  //  * Expected result: Fail (Student not enrolled.)
  //  */
  cout << "AC3 result:" << endl;
  busPass.validateBusPass(notEnrolledStudent);
  //  * AC4( TC 6):
  //  * 1. valid student ID
  //  * 2. valid enrolment status
  //  * 3. Invalide BusPass
  //  * Expected result: Fail ("BUS PASS INACTIVE")
  //  */
  cout << "AC4 result:" << endl;
  busPass.validateBusPass(Student("987", 100));
  cout << "------------" << endl;

  /**
   * Omar Kato
   * Student not in database or not enrolled
   */
  Student studentTwo = Student("456", 0);
  Device booking = Device(002, "Library", db, "Room");
  booking.book(studentTwo, "100_1-2");

  // Room Available and student in database
  Student studentThree = Student("123", 0);
  booking.book(studentThree, "200_1-2");

  // Student already booked
  Student studentFour = Student("123", 0);
  booking.book(studentFour, "100_1-2");

  // Room is not available
  Student studentFive = Student("789", 0);
  booking.book(studentTwo, "200_1-2");
  cout << "------------" << endl;

  // /**
  //  * Test case - story #8 - Mohammed Alhasan
  //  * Acceptance Criteria:
  //  * Enrolled student with parking pass
  //  * Expected Result - PASS - Due to Parking Pass
  //  */
  cout << "User Story #8" << endl;
  cout << "AC1 result:" << endl;
  Student sp1 = Student("123", 0);
  Device parkingGate1 = Device(004, "Parking", db, "Student");
  parkingGate1.perform(sp1, "AccessParking", 15);
  // /**
  //  * Enrolled student with Private Parking
  //  * Expected Result - PASS - Due to Private Parking
  //  */
  cout << "AC2 result:" << endl;
  Student sp2 = Student("789", 0);
  Device parkingGate2 = Device(005, "Parking", db, "Student");
  parkingGate2.perform(sp2, "AccessParking", 15);
  // /**
  //  * Enrolled Student with no parking pass but has enough balance
  //  * Expected Result - PASS - Due to having enough balance
  //  */
  cout << "AC3 result:" << endl;
  Student sp3 = Student("987", 100);
  Device parkingGate3 = Device(004, "Parking", db, "Student");
  parkingGate3.perform(sp3, "AccessParking", 15);
  // /** Enrolled Student with no parking pass and not enough balance
  //  * Expected Result - FAIL - Due to Balance < Cost
  //  */
  cout << "AC4 result:" << endl;
  Student sp4 = Student("987", 0);
  Device parkingGate4 = Device(004, "Parking", db, "Student");
  parkingGate4.perform(sp4, "Access Parking", 15);
  // /** Invalid Student ID
  //  * Expected Result - FAIL - Due to ID Not Found in Database
  //  */
  cout << "AC5 result:" << endl;
  Student sp5 = Student("000", 0);
  Device parkingGate5 = Device(004, "Parking", db, "Student");
  parkingGate5.perform(sp5, "AccessParking", 15);
  cout << "--------------------------------" << endl;

  // /**
  //  * Rami - Test case 1
  //  * Student not in database
  //  */
  Student sm1 = Student("900", 0);
  Device mealplan = Device(900, "Cafeteria", db, "Student");
  mealplan.ValidateMP(sm1);

  // // Can use meal plan
  Student sm2 = Student("123", 0);
  Device mealplan2 = Device(846, "Cafeteria", db, "Student");
  mealplan2.ValidateMP(sm2);

  // // Exceeded daily limit
  Student sm3 = Student("789", 0);
  Device mealplan3 = Device(485, "Cafeteria", db, "Student");
  mealplan3.ValidateMP(sm3);

  // // Invalid or expired meal plan
  Student sm4 = Student("369", 0);
  Device mealplan4 = Device(711, "Cafeteria", db, "Student");
  mealplan4.ValidateMP(sm4);
  cout << "------------" << endl;

  // Rami Abdul Majeed - Test cases for printer and scanner access

  // Student not in database
  Student s1 = Student("321", 100);
  Device printscan1 = Device(123, "Library", db, "Student");
  printscan1.printScan(s1, "Printer", "No", 60);

  cout << "------------" << endl;

  // Student in database
  // Enough credit to use printer
  Student s2 = Student("123", 100);
  Device printscan2 = Device(123, "Library", db, "Student");
  printscan2.printScan(s2, "Printer", "No", 60);

  cout << "------------" << endl;

  // Student in database
  // Not enough credit to use scanner
  // Chooses not to add credit to account
  Student s3 = Student("123", 10);
  Device printscan3 = Device(456, "Library", db, "Student");
  printscan3.printScan(s3, "Scanner", "No", 60);

  cout << "------------" << endl;

  // Student in database
  // Not enough credit to use printer
  // Chooses to add credit to account
  Student s4 = Student("789", 10);
  Device printscan4 = Device(456, "Library", db, "Student");
  printscan3.printScan(s4, "Printer", "Yes", 60);

  cout << "------------" << endl;

  // Student in database
  // No available credit to use scanner
  // Chooses not to add credit to account
  Student s5 = Student("987", 0);
  Device printscan5 = Device(123, "Library", db, "Student");
  printscan5.printScan(s5, "Scanner", "No", 60);

  cout << "------------" << endl;

  // Student in database
  // No available credit to use printer
  // Chooses to add credit to account
  Student s6 = Student("987", 0);
  Device printscan6 = Device(123, "Library", db, "Student");
  printscan6.printScan(s6, "Printer", "Yes", 60);
  cout << "------------" << endl;
  // /**
  //  * Test case - story #15 - Mohammed Alhasan
  //  * Enrolled Student with a valid student access privilege to certain facilities
  //  * Expected Result - PASS - Having Access Permission To Facilities
  //  */
  cout << "User Story #15" << endl;
  cout << "AC1 result:" << endl;
  Student sb1 = Student("123", 0);
  Device MC_Building1 = Device(006, "MC", db, "Student");
  MC_Building1.perform(sb1, "AccessBuilding", 0);
  // /** Invalid Student ID
  //  * Expected Result - FAIL - Due to ID Not Found in Database
  //  */
  cout << "AC2 result:" << endl;
  Student sb2 = Student("000", 0);
  Device MC_Building2 = Device(006, "MC", db, "Student");
  MC_Building2.perform(sb2, "AccessBuilding", 0);
  // /** Enrolled Student with a valid student access privilege to residence
  //  * Expected Result - PASS - Due to Having Access Permission to Residence
  //  */
  cout << "AC3 result:" << endl;
  Student sb3 = Student("789", 0);
  Device EH_Building1 = Device(007, "EH", db, "Student");
  EH_Building1.perform(sb3, "AccessBuilding", 0);
  // /** Enrolled Student with no valid Student access privilege to residence
  //  * Expected Result - FAIL - Due to Not Having Access Permission to Residence
  //  */
  cout << "AC4 result:" << endl;
  Student sb4 = Student("987", 0);
  Device EH_Building2 = Device(007, "EH", db, "Student");
  EH_Building2.perform(sb4, "AccessBuilding", 0);
  // /** Enrolled Student with no valid Student access privilege to certain facilities
  //  * Expected Result - FAIL - Due to Not Having Access Permission to certain facilities
  //  */
  cout << "AC5 result:" << endl;
  Student sb5 = Student("987", 0);
  Device NSB_Building = Device(010, "NSB", db, "Student");
  NSB_Building.perform(sb5, "AccessBuilding", 0);
  cout << "--------------------------------" << endl;

  Student s = Student("123", 500.00);
  Device storeCashier = Device(1, "Campus Bookstore", db, "Product");
  Device pharmCashier = Device(2, "Pharmacy", db, "Product");

  /** -------------------------------------
   * Test cases - story #6 - Kareem Elgendy
   * Acceptance Criteria:
   * 1. Initial balance should equal 500
   * 2. The new balance should equal 450
   * 3. Purchase completed successfully
   */
  storeCashier.purchase(s, "Western Hoodie");

  /** -------------------------------------
   * Test cases - story #6 - Kareem Elgendy
   * Acceptance Criteria:
   * 1. Product out of stock
   */
  storeCashier.purchase(s, "Western Tshirt");

  /** -------------------------------------
   * Test cases - story #6 - Kareem Elgendy
   * Acceptance Criteria:
   * 1. Product not sold in store
   */
  storeCashier.purchase(s, "Advil");

  cout << "--------------------------------" << endl;

  /** -------------------------------------
   * Test cases - Omar Kato
   * Acceptance Criteria:
   * 1. Student should get a refund
   */
  storeCashier.refund(s, "Western Hoodie");

  /** -------------------------------------
   * Test cases - Omar Kato
   * Acceptance Criteria:
   * 1. Student shouldn't get a refund
   */
  storeCashier.refund(s, "Advil");

  /** -------------------------------------
   * Test cases - Omar Kato
   * Acceptance Criteria:
   * 1. Student should get a refund
   */
  storeCashier.refund(s, "Western Tshirt");

  cout << "--------------------------------" << endl;
}
