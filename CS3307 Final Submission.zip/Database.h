/**
 * @authors Kareem Elgendy, Omar Kato
 * @brief This is the header file for the database class
 */

#ifndef DATABASE_H
#define DATABASE_H

#include <iostream>
#include <string>
#include <sqlite3.h>
#include <vector>
#include "Table.h"

using namespace std;

class Database
{
private:
    string name;
    sqlite3 *db;
    vector<Table> tables;

public:
    Database(string name);
    ~Database();
    void createTable(string tableName, string command);
    void dropTable(string tableName);
    Table getTable(string tableName);
};

#endif