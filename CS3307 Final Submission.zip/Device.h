/**
 * @authors Rami Abdul Majeed, Sara Al-Abbasi, Mohamed Alhasan, Kareem Elgendy, Omar Kato
 * @brief This is the header file for the device class
 */

#ifndef DEVICE_H
#define DEVICE_H

#include <fstream>
#include <string>
#include <iostream>
#include <vector>
#include <algorithm>
#include <iomanip>
#include "Database.h"
#include "Table.h"
#include "Student.h"

using namespace std;

class Device
{
private:
    int id;
    Table table;
    string location;
    bool validate(Student student);
    int validateParking(Student student);

public:
    Device(int id, string location, Database db, string tableName);
    ~Device();
    void perform(Student student, string action, int value = 0);
    bool book(Student student, string roomNum);
    bool ValidateMP(Student student);
    bool validateBusPass(Student student);
    void printScan(Student student, string selection, string UpdateBal, int amount);
    void purchase(Student student, string productID);
    void refund(Student student, string productID);
};

#endif
