var searchData=
[
  ['dbptr_0',['DBptr',['../struct_table.html#ad77636a6b79711b3b2aac39e7e2118df',1,'Table']]]
];
