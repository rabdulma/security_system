var searchData=
[
  ['query_0',['query',['../struct_table.html#ab0487341984122940d1f2ad665cef569',1,'Table']]]
];
