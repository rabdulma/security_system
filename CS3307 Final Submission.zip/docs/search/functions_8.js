var searchData=
[
  ['setbalance_0',['setBalance',['../class_student.html#a000a4285b79c0e92343fac47dc6af004',1,'Student']]],
  ['setid_1',['setID',['../class_student.html#ae3e0f29b2a134a205498c8cb86e97e76',1,'Student']]],
  ['student_2',['Student',['../class_student.html#aae835db75ab89dc803a4e88df8445062',1,'Student']]]
];
