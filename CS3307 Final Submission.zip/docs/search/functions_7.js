var searchData=
[
  ['refund_0',['refund',['../class_device.html#af0e25cfa43590afe960d2d8e7e4ea351',1,'Device']]],
  ['remove_1',['remove',['../struct_table.html#a0c67e0eb10bae3f2a75bc7094273c3a3',1,'Table']]]
];
