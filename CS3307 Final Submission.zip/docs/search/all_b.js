var searchData=
[
  ['keyinfo_0',['KeyInfo',['../struct_key_info.html',1,'']]]
];
