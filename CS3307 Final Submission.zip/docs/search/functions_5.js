var searchData=
[
  ['perform_0',['perform',['../class_device.html#ad90aefe4998ee506994a380fdf279114',1,'Device']]],
  ['printscan_1',['printScan',['../class_device.html#a30d8de97ba84d4a3c8c41afda347912e',1,'Device']]],
  ['purchase_2',['purchase',['../class_device.html#ab4f4dc8723349df169fd3f7d41e00c77',1,'Device']]]
];
