# Card Based Security System

**Group 6**

## Instructions

1. Run `make` OR `g++ Main.cpp Student.cpp Device.cpp -o control_center` to compile program
2. Run:
    1. `./control_center Regression` to run regression testing
    2. `./control_center <student_id> <student_balance> <action> <location> <action_based_parameters>` to perform an action
        Each action is unique, so aditional parameters may or may not be required. Below is a list of the actions and their corresponding parameters:
        If action == "purchaseFood" then <action_based_parameters> == int costOfItem
        If action == "increaseBalance" then <action_based_parameters> == int balance
        If action == "purchase" then <action_based_parameters> == string productName
        If action == "refund" then <action_based_parameters> == string productName
        If action == "viewBalance" then <action_based_parameters> == 0
        If action == "validateBusPass" then no <action_based_parameters> required
        If action == "bookRoom" then <action_based_parameters> string roomID
        If action == "accessParking" then <action_based_parameter> == int costOfParking
        If action == "ValidateMP" then no <action_based_parameters> required
        If action == "printScan" then <action_based_parameters1> == string selection, <action_based_parameters2> == string updateBal(yes,no), <action_based_parameters3> ==  int cost
        If action == "AccessBuilding" then  <action_based_parameter> == 0
    3. `./control_center Admin <tableName><command><command_based_parameters>` 
    Each command is unique, so aditional parameters will be required depending on the command. Below is a list of all the possible commands that manage tables in the database :
        1. Register student:
        `./control_center Admin Student register_student <ID> <Name> <ENROLMENT> <BUS_PASS> <PARKING_PASS> <MEAL_PLAN> <MEAL_PLAN_LIMIT_REACHED> <MC_PERMISSION> <NSB_PERMISSION> <EH_PERMISSION>`
        2. Remove student:
        `./control_center Admin Student remove_student <student_id>`
        3. Update student info:
        `./control_center Admin Student update_student_info <student_id>, <columnName>, <newValue>`
        4. Add room:
        `./control_center Admin Room add_room <ROOM_ID> <AVAILABILITY> <STUDENT_ID>`
        5. Remove room:
        `./control_center Admin Room remove_room <Room_ID>`
        6. Update room info:
        `./control_center Admin Room update_room_info <room_id>, <columnName>, <newValue>`
        7. Add location:
        `./control_center Admin Location <action> <location_id> <location_name>`
        8. Remove location:
        `./control_center Admin Location <action> <location_id>`
        9. Update location:
        ` ./control_center Admin Location <action> <location_id> <column> <newValue>`
        10. Add product:
        `./control_center Admin Product <action> <product_id> <location_name> <product_name> <product_price> <product_stock>`
        11. Remove product:
        ` ./control_center Admin Product <action> <product_id>`
        12. Update product:
        `./control_center Admin Product <action> <product_id> <column> <newValue>`



`git config --global user.name "FIRST_NAME LAST_NAME"`

`git config --global user.email "example@gmail.com"`

To add files:
`git add`

To commit staged changes:
`git commit -m "message here"`

To push commit:
`git push`

To pull changes:
`git pull`