/**
 * @authors Kareem Elgendy, Omar Kato
 * @brief This is the header file for the table class
 */

#ifndef TABLE_H
#define TABLE_H

#include <iostream>
#include <string>
#include <sqlite3.h>

using namespace std;

class Table
{
private:
    string name;    /**< The name of the table */
    string columns; /**< The list of columns within the table */
    sqlite3 *DBptr; /**< A pointer to the SQL .db Database */

public:
    Table();
    Table(string name, string columns, sqlite3 *DBptr);
    ~Table();
    void insert(string values);
    void remove(string id);
    void update(string id, string column, string newValue, string tableName = "Student", string target = "ID");
    string query(string id, string column, string tableName = "Student", string target = "ID");
    string getName();
};

#endif