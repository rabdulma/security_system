/**
 * @authors Kareem Elgendy, Omar Kato, Sara Al-Abbasi
 * @brief This class represents the tables and is responsible for creating Table objects
 */
#include "Table.h"

/**
 * @brief Default constructor for Table:: Table object
 * @author Mohammed Alhasan
 */
Table::Table() {}

/**
 * @brief Construct a new Table:: Table object
 * @details Creates a Object of type Table and initializes an SQL command
 * statement create a table using the input parameters
 * @param name - Table name or type string
 * @param columns - string composed of the column names within the table
 * @param DBptr - a pointer to the SQL .db Database
 */
Table::Table(string name, string columns, sqlite3 *DBptr)
{
    this->name = name;
    this->DBptr = DBptr;

    char *msg;
    int exit = 0;
    string command = "CREATE TABLE IF NOT EXISTS " + name + "(" + columns + ");";
    sqlite3_exec(DBptr, command.c_str(), NULL, 0, &msg);
}

/**
 * @brief Destroy the Table:: Table object
 */
Table::~Table() {}

/**
 * @brief Table Name Getter method
 * @return string - Name of Table Object
 */
string Table::getName()
{
    return this->name;
}

/**
 * @brief Inserts new rows to tables
 * @details This method takes input values and places them into an SQL Insert command
 * which addes the parameter values as a new row into this Table
 * @param values - string parameter which includes the list of values
 * that are to be added into the columns of the table forming anew row
 */
void Table::insert(string values)
{
    char *msg;
    string command = "INSERT INTO " + this->name + " VALUES(" + values + ");";
    sqlite3_exec(DBptr, command.c_str(), NULL, 0, &msg);
}

/**
 * @brief Deletes an entire row from this table using the table's key as an identifier for the row
 * @param id - Table ID and Primary Key for the table
 */
void Table::remove(string id)
{
    char *msg;
    string command = "DELETE FROM " + this->name + " WHERE ID='" + id + "';";
    sqlite3_exec(DBptr, command.c_str(), NULL, 0, &msg);
}

/**
 * @brief Modifies existing rows within this table
 * @details This method takes in input values and places them into an SQL Update command
 * which modifies the data in the specified table using the parameter values provided
 * @param id - value identifing the row to be modified
 * @param column - column where data is to be modified
 * @param newValue - new data to be add into the selected cell
 * @param tableName - name of table to be updated
 * @param target - name of column of where id resides
 */
void Table::update(string id, string column, string newValue, string tableName, string target)
{
    char *msg;
    string command = "UPDATE " + tableName + " SET " + column + "='" + newValue + "' WHERE " + target + "='" + id + "';";
    sqlite3_exec(DBptr, command.c_str(), NULL, 0, &msg);
}

/**
 * @brief Queries the database using the input parameters
 * @details Initialises an SQL Select command which requests data from the database given the parameters provided
 * @param id - value used to identify the cells in question
 * @param column - Table Columns that are to be used in the query
 * @param tableName - Name of Table that is queried
 * @param target - name of column of where id resides
 * @return string - empty string if query nets no result | string - the result of the query
 */
string Table::query(string id, string column, string tableName, string target)
{
    char *msg;
    string result;
    sqlite3_stmt *stmt;
    string command = "SELECT " + column + " FROM " + tableName + " WHERE " + target + "='" + id + "';";
    sqlite3_prepare_v2(DBptr, command.c_str(), -1, &stmt, NULL);
    if (sqlite3_step(stmt) == SQLITE_DONE)
    {
        return "";
    }
    else
    {
        result = (char *)sqlite3_column_text(stmt, 0);
    }
    return result;
}