/**
 * @authors Rami Abdul Majeed, Sara Al-Abbasi, Mohamed Alhasan, Kareem Elgendy, Omar Kato
 * @brief This class represents the device and is responsible for creating Device objects
 */

#include "Device.h"

/**
 * @brief Class constructor
 * @param id The device ID
 * @param location The device's location
 */
Device::Device(int id, string location, Database db, string tableName)
{
    this->id = id;
    this->location = location;
    this->table = db.getTable(tableName);
}

/**
 * @brief Class destructor
 */
Device::~Device() {}

/**
 * @brief Validates that a student has a valid ID and is enrolled
 * @param student The student object
 * @return Whether the student is valid or not
 */
bool Device::validate(Student student)
{

    string enrolment = table.query(student.getID(), "Enrolment");
    if (enrolment == "YES")
        return true;
    else if (enrolment == "NO")
    {
        cout << "Student not enrolled" << endl;
        return false;
    }
    else
    {
        cout << "Student not found in database." << endl;
        return false;
    }
}

/**
 * @brief Validates that a student has a valid ID and is enrolled
 * Once student is validated, checks for bus privileges
 * @param student: student object
 * @return Whether the student is valid or not and if student has bus privileges
 */
bool Device::validateBusPass(Student student)
{
    bool validStudent = validate(student);
    if (!validStudent)
        return false;
    string BUS_PASS = table.query(student.getID(), "BUS_PASS");
    if (BUS_PASS == "ACTIVE")
    {
        cout << "BUS PASS ACTIVE. PLEASE FIND A SEAT" << endl;
        return true;
    }
    else if (BUS_PASS == "INACTIVE")
    {
        cout << "BUS PASS INACTIVE" << endl;
        return false;
    }
    return false;
}

/**
 * @brief Validates that a student has a valid parking pass
 * @param student The student object
 * @return Number (1 or 2) representing different parking passes or 0
 */
int Device::validateParking(Student student)
{
    string PARKING_PASS_STATUS = table.query(student.getID(), "PARKING_PASS");

    if (PARKING_PASS_STATUS == "ACTIVE")
    {

        return 1;
    }
    else if (PARKING_PASS_STATUS == "PRIVATE")
    {

        return 2;
    }
    else if (student.getBalance() >= 15)
    {

        return 3;
    }
    else if (!validate(student))
    {

        return -2;
    }
    else
    {

        return -1;
    }
}

/**
 * Performs specified action
 * @param student The student object
 * @param action The action to be performed
 * @param value The amount associated with the action
 */
void Device::perform(Student student, string action, int value)
{
    bool validStudent = validate(student);

    if (!validStudent)
        return;

    bool actionStatus = false;
    string statement = "Student with studentID " + student.getID() + " performed " + action;

    if (action == "increase balance")
    {
        actionStatus = true;
        if (value)
        {
            cout << "Previous balance: $";
            cout << fixed << setprecision(2) << student.getBalance() << endl;
            student.setBalance("increment", value);
            cout << "New balance: $";
            cout << fixed << setprecision(2) << student.getBalance() << endl;
        }
        else
            cout << "Error: amount should be greater than 0." << endl;
    }
    else if (action == "purchaseFood")
    {
        if (student.getBalance() >= value)
        {
            actionStatus = true;
            cout << "Purchase completed successfully" << endl;
            cout << "Balance before purchase: $";
            cout << fixed << setprecision(2) << student.getBalance() << endl;
            student.setBalance("decrement", value);
            cout << "Balance after purchase: $";
            cout << fixed << setprecision(2) << student.getBalance() << endl;
        }
        else
            cout << "You do not have enough credit." << endl;
    }
    else if (action == "viewBalance")
    {
        actionStatus = true;
        cout << "Your balance is: " << student.getBalance() << endl;
    }
    else if (action == "AccessParking")
    {
        actionStatus = true;
        int validParking = validateParking(student);

        if (validParking == 1)
        {
            cout << "Access Granted - Parking Pass" << endl;
        }
        else if (validParking == 2)
        {
            cout << "Access Granted - Private Slot" << endl;
        }
        else if (validParking == 3)
        {
            cout << "Access Granted - Balance" << endl;
            cout << "Balance: $" << fixed << setprecision(2) << student.getBalance() << endl;
            student.setBalance("decrement", value);
            cout << "New Balance: $";
            cout << fixed << setprecision(2) << student.getBalance() << endl;
        }
        else if (validParking == -2)
        {

            cout << "Student not found in database." << endl;
        }
        else
        {
            cout << "Access Denied" << endl;
            cout << "Parking Pass Status: " << table.query(student.getID(), "PARKING_PASS") << endl;
            cout << "Balance: $" << fixed << setprecision(2) << student.getBalance() << endl;
        }
    }
    else if (action == "AccessBuilding")
    {

        actionStatus = true;

        if (table.query(student.getID(), location + "_PERMISSION") == "YES")
        {

            cout << "Access Granted";

            if (location == "MC")
            {

                cout << " - Middlesex College" << endl;
            }
            else if (location == "NSB")
            {

                cout << " - Natural Science Building" << endl;
            }
            else if (location == "EH")
            {

                cout << " - Elgin Hall" << endl;
            }
        }
        else
        {

            cout << "Access Denied" << endl;
        }
    }

    if (actionStatus)
        cout << statement << endl;
    else
        cout << "Error occurred device could not complete the action." << endl;
}

/**
 * @brief Books a room for a student at a specific hour
 * @param student The student object
 * @param roomNum The target room
 * @param hour The hour
 * @return Whether the student's booking is valid
 */
bool Device::book(Student student, string room)
{

    if (validate(student))
    {
        string studentID = "";
        string rooms = table.query(room, "AVAILABILITY", "Room");
        bool check = true;
        int start = 1;
        int end = 2;
        for (int i = 0; i < 3; i++)
        {
            for (int j = 1; j < 5; j++)
            {
                string roomNum = to_string(j) + "00_" + to_string(start) + "-" + to_string(end);
                studentID = table.query(roomNum, "STUDENT_ID", "Room");
                if (studentID == student.getID())
                {
                    check = false;
                }
            }
            start += 2;
            end += 2;
        }
        if (check)
        {
            if (rooms == "YES")
            {
                table.update(room, "STUDENT_ID", student.getID(), "Room");
                table.update(room, "AVAILABILITY", "NO", "Room");
            }
            else
            {
                cout << "Cannot book, room not available" << endl;
            }
        }
        else
        {
            cout << "Cannot book, student already booked another room" << endl;
        }
    }
    else
    {
        cout << "Cannot book" << endl;
        return false;
    }

    return false;
}

/**
 * @brief Validates a student's meal plan and checks if
 * they exceeded the daily limit
 * @param student The student object
 * @return Whether the student has an active meal plan
 */
bool Device::ValidateMP(Student student)
{
    bool isValid;
    isValid = validate(student);

    if (!isValid)
    {
        return false;
    }
    else
        cout << "Student ID is valid" << endl;

    string mealPlan = table.query(student.getID(), "MEAL_PLAN");
    string mealPlanLimit = table.query(student.getID(), "MEAL_PLAN_LIMIT_REACHED");

    if (mealPlan == "YES")
    {
        if (mealPlanLimit == "YES")
        {
            cout << "You have exceeded the daily limit" << endl;
            return true;
        }
        else
        {
            cout << "You may use your meal plan to purchase" << endl;
            return false;
        }
    }
    else
    {
        cout << "Invalid or expired meal plan" << endl;
        return false;
    }

    return false;
}

/**
 * @brief Validates that a student has a valid ID and is enrolled
 * Once student is validated, checks to see if student has
 * sufficient balance to use printer and scanner
 * @param student: The student object
 * @param selection: string variable
 * @param updateBal: string variable
 * @param cost: int variable
 * @return no return value
 */
void Device::printScan(Student student, string selection, string updateBal, int cost = 0)
{
    bool isValid;
    isValid = validate(student);

    if (!isValid)
    {
        return;
    }
    else
        cout << "Student ID is valid" << endl;

    if (selection == "Printer" || "Scanner")
    {
        if (student.getBalance() > 0 && student.getBalance() >= cost)
        {
            cout << "Funds available. You may proceed with your request" << endl;
            string curBalance = to_string(student.getBalance());
            student.setBalance("decrement", cost);
            string remBalance = to_string(student.getBalance());
            cout << "Your remaining balance is: $" + remBalance << endl;
            return;
        }

        if (student.getBalance() > 0 && student.getBalance() < cost)
        {
            cout << "Insufficent funds. Please add credit to your account to proceed with request" << endl;
            cout << "Do you wish to add funds to your account?" << endl;

            if (updateBal == "Yes")
            {
                string curBalance = to_string(student.getBalance());
                cout << "Your current balance is: $" + curBalance << endl;
                student.setBalance("increment", cost);
                string newBalance = to_string(student.getBalance());
                cout << "Your new balance is: $" + newBalance << endl;
            }

            else
                cout << "Have a good day!" << endl;
            return;
        }

        if (student.getBalance() == 0)
        {
            cout << "No funds available" << endl;
            cout << "Do you wish to add funds to your account?" << endl;

            if (updateBal == "Yes")
            {
                string curBalance = to_string(student.getBalance());
                cout << "Your current balance is: $" + curBalance << endl;
                student.setBalance("increment", cost);
                string newBalance = to_string(student.getBalance());
                cout << "Your new balance is: $" + newBalance << endl;
            }
            else
                cout << "Have a good day!" << endl;
            return;
        }
    }
}

/**
 * @brief Validates that a student has a valid ID and is enrolled
 * Checks product availability per location and product stock
 * Updates student balance upon purchase
 * @param student: student object
 * @param product: string variable
 * @return no return value
 */
void Device::purchase(Student student, string product)
{
    if (validate(student))
    {
        string stock = table.query(product, "STOCK", "Product", "NAME");
        string price = table.query(product, "PRICE", "Product", "NAME");
        string location = table.query(product, "LOCATION", "Product", "NAME");

        if (location != this->location)
        {
            cout << "Store does not carry this product." << endl;
        }
        else if (stock == "0")
        {
            cout << "Product out of stock." << endl;
        }
        else if (stock == "")
        {
            cout << "Invalid product" << endl;
        }
        else
        {
            int pStock = stoi(stock);
            if (student.getBalance() >= stold(price) && pStock)
            {
                cout << "Balance before purchase: $";
                cout << fixed << setprecision(2) << student.getBalance() << endl;
                student.setBalance("decrement", stold(price));
                table.update(product, "STOCK", to_string(pStock - 1), "PRODUCT", "NAME");
                cout << "Balance after purchase: $";
                cout << fixed << setprecision(2) << student.getBalance() << endl;
                cout << "Purchase completed successfully" << endl;
            }
        }
    }
    else
    {
        cout << "Invalid student, cannot purchase" << endl;
    }
}

/**
 * @brief Validates that a student has a valid ID and is enrolled
 * Checks product availability per location and product stock
 * Updates student balance upon refund
 * @param student: student object
 * @param product: string variable
 * @return no return value
 */
void Device::refund(Student student, string product)
{

    if (validate(student))
    {
        string stock = table.query(product, "STOCK", "Product", "NAME");
        string price = table.query(product, "PRICE", "Product", "NAME");
        string location = table.query(product, "LOCATION", "Product", "NAME");

        if (location != this->location)
        {
            cout << "Store does not carry this product." << endl;
        }
        else if (stock == "")
        {
            cout << "Invalid product" << endl;
        }
        else
        {
            cout << "Balance before refund: $";
            cout << fixed << setprecision(2) << student.getBalance() << endl;
            int pStock = stoi(stock);
            student.setBalance("increment", stold(price));
            table.update(product, "STOCK", to_string(pStock + 1), "PRODUCT", "NAME");
            cout << "Balance after refund: $";
            cout << fixed << setprecision(2) << student.getBalance() << endl;
            cout << "Return completed successfully" << endl;
        }
    }
    else
    {
        cout << "Invalid student, cannot refund" << endl;
    }
}